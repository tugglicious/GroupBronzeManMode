# JSONBin.io Setup Guide for Group Bronzeman Mode

This guide will walk you through setting up JSONBin.io for your Group Bronzeman Mode plugin. JSONBin.io is a simple, free JSON storage service that makes group synchronization incredibly easy!

## Why JSONBin.io?

- ✅ **Super Simple** - Just 3 things to configure (account, API key, bin ID)
- ✅ **Free** - Generous free tier (perfect for this use case)
- ✅ **No Bot Setup** - Unlike Discord, no complicated bot creation
- ✅ **Fast** - Quick REST API calls
- ✅ **Reliable** - Designed specifically for JSON storage

## Step-by-Step Setup

### Step 1: Create a JSONBin.io Account

1. Go to https://jsonbin.io/
2. Click **"Sign Up"** (top right)
3. Create an account with your email
4. Verify your email address
5. Log in to your account

### Step 2: Get Your API Key

1. Once logged in, click on your profile icon (top right)
2. Click **"API Keys"** from the dropdown menu
3. You'll see your **X-Master-Key** - this is your API key
4. Click **"Copy"** to copy your API key
5. **SAVE THIS KEY** - You'll need it for the plugin configuration
   - ⚠️ **NEVER share this key publicly!**

### Step 3: Create a Bin (Storage Container)

1. From the dashboard, click **"Create Bin"**
2. In the JSON editor, paste this initial structure:
   ```json
   {
     "unlockedItems": {},
     "lastUpdated": 0
   }
   ```
3. Click **"Create"** or **"Save"**
4. You'll be taken to your new bin's page
5. Look at the URL - it will look like:
   ```
   https://jsonbin.io/api/bins/65abc123def456789
   ```
6. The part after `/bins/` is your **Bin ID** (e.g., `65abc123def456789`)
7. **SAVE THIS BIN ID** - You'll need it for the plugin configuration

### Step 4: Configure Privacy Settings (Optional)

1. On your bin's page, click **"Settings"** or the gear icon
2. For group play, you can leave it as **Private** (recommended)
3. All group members will use the same API key to access the bin

### Step 5: Configure the RuneLite Plugin

Now that you have your credentials, configure the plugin:

1. Open RuneLite
2. Click the **Configuration** wrench icon (top right)
3. Search for **"Group Bronzeman Mode"**
4. Enter your **JSONBin Settings**:
   - **API Key**: Paste your X-Master-Key from Step 2
   - **Bin ID**: Paste your Bin ID from Step 3

5. Configure **Group Settings** (optional):
   - **Group Name**: Your group's name (cosmetic)
   - **Enable Unlock Notifications**: Show in-game messages (recommended)
   - **Sync Interval**: How often to check for new unlocks (default: 5 minutes)
   - **Auto Sync**: Automatically sync periodically (recommended)
   - **Show Who Unlocked**: Show which player unlocked each item

### Step 6: Share with Your Group

All group members need to use the **same credentials**:

**Share these with your group** (via a secure method):
1. **API Key**: `[PASTE YOUR API KEY HERE]`
2. **Bin ID**: `[PASTE YOUR BIN ID HERE]`

⚠️ **Important**: Everyone must use the exact same API key and Bin ID!

### Step 7: Test It Out!

1. Start RuneLite with the plugin enabled
2. Log into OSRS
3. Open your bank (this will unlock all your current items)
4. Check the RuneLite logs - you should see messages about syncing
5. Go to https://jsonbin.io/ and check your bin - you should see item data!
6. Have a group member do the same - their unlocks will appear too!

## How It Works

```
Player 1 gets item → Plugin unlocks locally → Pushes to JSONBin
                                                      ↓
Player 2's plugin ← Syncs every 5 minutes ← Reads from JSONBin
```

- When you unlock an item, it's immediately pushed to JSONBin
- Every 5 minutes (configurable), your plugin checks JSONBin for new unlocks
- All group members share the same unlock list
- No server maintenance required!

## Troubleshooting

### "Failed to fetch from JSONBin"

**Possible causes:**
- Incorrect API key - make sure you copied it correctly
- Incorrect Bin ID - double-check the ID from the URL
- Network issues - check your internet connection
- Rate limiting - free tier has limits (shouldn't be an issue for normal play)

**Solution:**
1. Go to https://jsonbin.io/ and verify your API key
2. Check your bin exists and copy the ID from the URL
3. Re-enter the credentials in RuneLite config

### "Items not syncing with group"

**Possible causes:**
- Group members using different bins
- Auto sync disabled
- Different API keys

**Solution:**
1. Verify all group members have the exact same API key and Bin ID
2. Check "Auto Sync" is enabled in config
3. Manually trigger sync by restarting the plugin

### "Bin not updating"

**Possible causes:**
- API key doesn't have write permissions
- Reached free tier limits

**Solution:**
1. Check your JSONBin.io account dashboard for any alerts
2. Verify API key has read/write permissions
3. Check your usage limits on the dashboard

## JSONBin.io Free Tier Limits

As of 2025, the free tier includes:
- **Requests**: Generous request limit (plenty for group play)
- **Storage**: 10MB per bin (more than enough for item lists)
- **Bins**: Multiple bins allowed

For a group of players, you'll be well within these limits!

## Privacy & Security

⚠️ **Keep your API key private!** Anyone with your API key and Bin ID can:
- Read your group's unlocks
- Modify your group's unlocks
- Delete the bin

**Best practices:**
1. Only share credentials with trusted group members
2. Use a secure method to share (Discord DM, not public channels)
3. If compromised, create a new bin and API key
4. Consider creating a separate JSONBin account just for this plugin

## Advanced: Multiple Groups

Want to play in multiple groups?

1. Create multiple bins (one per group)
2. Each bin gets a unique Bin ID
3. Switch between groups by changing the Bin ID in config
4. API key can stay the same (or use different accounts)

## Support

Having issues?

1. Check the RuneLite logs for error messages
2. Visit your bin at https://jsonbin.io/ to see if data is being stored
3. Verify your API key and Bin ID are correct
4. Check the main README.md for more troubleshooting tips

## Useful Links

- JSONBin.io: https://jsonbin.io/
- JSONBin.io Docs: https://jsonbin.io/api-reference
- RuneLite Plugin Hub: https://runelite.net/plugin-hub/

---

That's it! You're all set up. Happy scaping! 🎉
