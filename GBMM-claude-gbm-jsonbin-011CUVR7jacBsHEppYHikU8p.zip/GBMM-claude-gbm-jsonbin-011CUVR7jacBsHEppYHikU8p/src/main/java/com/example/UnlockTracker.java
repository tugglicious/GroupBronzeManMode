package com.example;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import lombok.extern.slf4j.Slf4j;
import net.runelite.client.config.ConfigManager;

import java.lang.reflect.Type;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
public class UnlockTracker
{
	private static final String CONFIG_GROUP = "gbmm";
	private static final String CONFIG_KEY = "unlockedItems";

	private final ConfigManager configManager;
	private final Gson gson;
	private final Set<Integer> unlockedItems;
	private final Map<Integer, String> itemNames; // itemId -> itemName

	public UnlockTracker(ConfigManager configManager)
	{
		this.configManager = configManager;
		this.gson = new Gson();
		this.unlockedItems = ConcurrentHashMap.newKeySet();
		this.itemNames = new ConcurrentHashMap<>();

		loadUnlocks();
	}

	/**
	 * Check if an item is unlocked
	 */
	public boolean isUnlocked(int itemId)
	{
		return unlockedItems.contains(itemId);
	}

	/**
	 * Unlock an item (returns true if this is a new unlock)
	 */
	public boolean unlockItem(int itemId, String itemName)
	{
		if (unlockedItems.add(itemId))
		{
			itemNames.put(itemId, itemName);
			saveUnlocks();
			log.info("New item unlocked: {} (ID: {})", itemName, itemId);
			return true;
		}
		return false;
	}

	/**
	 * Unlock multiple items from Discord sync
	 */
	public int unlockItems(List<DiscordClient.UnlockMessage> messages)
	{
		int newUnlocks = 0;
		for (DiscordClient.UnlockMessage message : messages)
		{
			if (unlockItem(message.itemId, message.itemName))
			{
				newUnlocks++;
			}
		}
		return newUnlocks;
	}

	/**
	 * Get all unlocked item IDs
	 */
	public Set<Integer> getUnlockedItems()
	{
		return new HashSet<>(unlockedItems);
	}

	/**
	 * Get the name of an unlocked item
	 */
	public String getItemName(int itemId)
	{
		return itemNames.getOrDefault(itemId, "Unknown Item");
	}

	/**
	 * Get count of unlocked items
	 */
	public int getUnlockCount()
	{
		return unlockedItems.size();
	}

	/**
	 * Clear all unlocks (for testing/reset purposes)
	 */
	public void clearUnlocks()
	{
		unlockedItems.clear();
		itemNames.clear();
		saveUnlocks();
		log.info("All unlocks cleared");
	}

	/**
	 * Save unlocks to config
	 */
	private void saveUnlocks()
	{
		try
		{
			Map<String, Object> data = new HashMap<>();
			data.put("items", new ArrayList<>(unlockedItems));
			data.put("names", itemNames);

			String json = gson.toJson(data);
			configManager.setConfiguration(CONFIG_GROUP, CONFIG_KEY, json);
		}
		catch (Exception e)
		{
			log.error("Failed to save unlocks", e);
		}
	}

	/**
	 * Load unlocks from config
	 */
	private void loadUnlocks()
	{
		try
		{
			String json = configManager.getConfiguration(CONFIG_GROUP, CONFIG_KEY);
			if (json == null || json.isEmpty())
			{
				log.info("No saved unlocks found");
				return;
			}

			Type type = new TypeToken<Map<String, Object>>(){}.getType();
			Map<String, Object> data = gson.fromJson(json, type);

			if (data.containsKey("items"))
			{
				List<?> itemsList = (List<?>) data.get("items");
				for (Object item : itemsList)
				{
					if (item instanceof Number)
					{
						unlockedItems.add(((Number) item).intValue());
					}
				}
			}

			if (data.containsKey("names"))
			{
				Map<?, ?> namesMap = (Map<?, ?>) data.get("names");
				for (Map.Entry<?, ?> entry : namesMap.entrySet())
				{
					try
					{
						int itemId = Integer.parseInt(entry.getKey().toString());
						String itemName = entry.getValue().toString();
						itemNames.put(itemId, itemName);
					}
					catch (NumberFormatException e)
					{
						log.warn("Failed to parse item ID: {}", entry.getKey());
					}
				}
			}

			log.info("Loaded {} unlocked items from config", unlockedItems.size());
		}
		catch (Exception e)
		{
			log.error("Failed to load unlocks", e);
		}
	}
}
