package com.example;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Slf4j
public class DiscordClient
{
	private static final String DISCORD_API_BASE = "https://discord.com/api/v10";
	private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");

	private final OkHttpClient httpClient;
	private final Gson gson;
	private final String botToken;
	private final String webhookUrl;

	public DiscordClient(String botToken, String webhookUrl)
	{
		this.botToken = botToken;
		this.webhookUrl = webhookUrl;
		this.gson = new Gson();

		this.httpClient = new OkHttpClient.Builder()
			.connectTimeout(10, TimeUnit.SECONDS)
			.readTimeout(10, TimeUnit.SECONDS)
			.writeTimeout(10, TimeUnit.SECONDS)
			.build();
	}

	/**
	 * Post an unlock message to Discord via webhook
	 */
	public boolean postUnlock(String playerName, int itemId, String itemName)
	{
		if (webhookUrl == null || webhookUrl.isEmpty())
		{
			log.warn("Webhook URL not configured");
			return false;
		}

		try
		{
			JsonObject embed = new JsonObject();
			embed.addProperty("title", "🔓 Item Unlocked!");
			embed.addProperty("description", String.format("**%s** unlocked **%s** (ID: %d)", playerName, itemName, itemId));
			embed.addProperty("color", 15844367); // Gold color
			embed.addProperty("timestamp", java.time.Instant.now().toString());

			JsonObject footer = new JsonObject();
			footer.addProperty("text", "Group Bronzeman Mode");
			embed.add("footer", footer);

			JsonArray embeds = new JsonArray();
			embeds.add(embed);

			JsonObject payload = new JsonObject();
			payload.add("embeds", embeds);

			// Store item data in the username field for easy parsing
			payload.addProperty("username", String.format("GBMM|%s|%d|%s", playerName, itemId, itemName));

			RequestBody body = RequestBody.create(JSON, gson.toJson(payload));
			Request request = new Request.Builder()
				.url(webhookUrl)
				.post(body)
				.build();

			try (Response response = httpClient.newCall(request).execute())
			{
				if (response.isSuccessful())
				{
					log.info("Successfully posted unlock to Discord: {} - {}", itemName, itemId);
					return true;
				}
				else
				{
					log.error("Failed to post to webhook: {} - {}", response.code(), response.message());
					return false;
				}
			}
		}
		catch (IOException e)
		{
			log.error("Error posting to Discord webhook", e);
			return false;
		}
	}

	/**
	 * Fetch recent messages from a Discord channel
	 */
	public List<UnlockMessage> fetchUnlocks(String channelId, int limit)
	{
		List<UnlockMessage> unlocks = new ArrayList<>();

		if (botToken == null || botToken.isEmpty())
		{
			log.warn("Bot token not configured");
			return unlocks;
		}

		if (channelId == null || channelId.isEmpty())
		{
			log.warn("Channel ID not configured");
			return unlocks;
		}

		try
		{
			String url = String.format("%s/channels/%s/messages?limit=%d", DISCORD_API_BASE, channelId, limit);

			Request request = new Request.Builder()
				.url(url)
				.header("Authorization", "Bot " + botToken)
				.get()
				.build();

			try (Response response = httpClient.newCall(request).execute())
			{
				if (!response.isSuccessful())
				{
					log.error("Failed to fetch messages from Discord: {} - {}", response.code(), response.message());
					return unlocks;
				}

				String responseBody = response.body().string();
				JsonArray messages = gson.fromJson(responseBody, JsonArray.class);

				for (JsonElement messageElement : messages)
				{
					JsonObject message = messageElement.getAsJsonObject();

					// Check if this is a webhook message from our bot
					if (!message.has("webhook_id"))
					{
						continue;
					}

					// Parse the username field which contains our data
					String username = message.get("username").getAsString();

					// Format: GBMM|playerName|itemId|itemName
					if (username.startsWith("GBMM|"))
					{
						String[] parts = username.substring(5).split("\\|", 3);
						if (parts.length == 3)
						{
							try
							{
								String playerName = parts[0];
								int itemId = Integer.parseInt(parts[1]);
								String itemName = parts[2];

								unlocks.add(new UnlockMessage(playerName, itemId, itemName));
							}
							catch (NumberFormatException e)
							{
								log.warn("Failed to parse item ID from message: {}", username);
							}
						}
					}
				}

				log.info("Fetched {} unlock messages from Discord", unlocks.size());
			}
		}
		catch (IOException e)
		{
			log.error("Error fetching messages from Discord", e);
		}

		return unlocks;
	}

	/**
	 * Simple data class for unlock messages
	 */
	public static class UnlockMessage
	{
		public final String playerName;
		public final int itemId;
		public final String itemName;

		public UnlockMessage(String playerName, int itemId, String itemName)
		{
			this.playerName = playerName;
			this.itemId = itemId;
			this.itemName = itemName;
		}
	}
}
