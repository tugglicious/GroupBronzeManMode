package com.example;

import com.google.inject.Provides;
import lombok.extern.slf4j.Slf4j;
import net.runelite.api.*;
import net.runelite.api.events.*;
import net.runelite.api.widgets.Widget;
import net.runelite.api.widgets.WidgetInfo;
import net.runelite.client.callback.ClientThread;
import net.runelite.client.config.ConfigManager;
import net.runelite.client.eventbus.Subscribe;
import net.runelite.client.game.ItemManager;
import net.runelite.client.plugins.Plugin;
import net.runelite.client.plugins.PluginDescriptor;
import net.runelite.client.util.Text;

import javax.inject.Inject;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Slf4j
@PluginDescriptor(
	name = "Group Bronzeman Mode",
	description = "Group Bronzeman Mode - unlock items together!",
	tags = {"bronzeman", "group", "ironman", "discord"}
)
public class ExamplePlugin extends Plugin
{
	@Inject
	private Client client;

	@Inject
	private ExampleConfig config;

	@Inject
	private ConfigManager configManager;

	@Inject
	private ItemManager itemManager;

	@Inject
	private ClientThread clientThread;

	@Inject
	private ScheduledExecutorService executor;

	private DiscordClient discordClient;
	private UnlockTracker unlockTracker;
	private final Set<Integer> pendingUnlocks = new HashSet<>();

	@Override
	protected void startUp() throws Exception
	{
		log.info("Group Bronzeman Mode started!");

		// Initialize unlock tracker
		unlockTracker = new UnlockTracker(configManager);

		// Initialize Discord client
		updateDiscordClient();

		// Perform initial sync from Discord
		syncFromDiscord();

		// Schedule periodic sync
		int syncMinutes = Math.max(1, Math.min(60, config.syncInterval()));
		executor.scheduleAtFixedRate(this::syncFromDiscord, syncMinutes, syncMinutes, TimeUnit.MINUTES);
	}

	@Override
	protected void shutDown() throws Exception
	{
		log.info("Group Bronzeman Mode stopped!");
		discordClient = null;
		unlockTracker = null;
		pendingUnlocks.clear();
	}

	@Subscribe
	public void onItemContainerChanged(ItemContainerChanged event)
	{
		// Check inventory and equipment for new items
		if (event.getContainerId() == InventoryID.INVENTORY.getId() ||
			event.getContainerId() == InventoryID.EQUIPMENT.getId())
		{
			ItemContainer container = event.getItemContainer();
			if (container != null)
			{
				for (Item item : container.getItems())
				{
					checkAndUnlockItem(item.getId());
				}
			}
		}
	}

	@Subscribe
	public void onWidgetLoaded(WidgetLoaded event)
	{
		// Check bank when it's opened
		if (event.getGroupId() == WidgetInfo.BANK_ITEM_CONTAINER.getGroupId())
		{
			clientThread.invokeLater(this::checkBankItems);
		}
	}

	@Subscribe
	public void onMenuOptionClicked(MenuOptionClicked event)
	{
		// Block Grand Exchange offers for locked items
		if (isGrandExchangeOffer(event))
		{
			int itemId = getItemIdFromMenuEntry(event);
			if (itemId > 0 && !unlockTracker.isUnlocked(itemId))
			{
				event.consume();

				String itemName = itemManager.getItemComposition(itemId).getName();
				client.addChatMessage(ChatMessageType.GAMEMESSAGE, "",
					"You cannot buy <col=ef1020>" + itemName + "</col> - you haven't unlocked it yet!",
					null);
			}
		}
	}

	private void checkBankItems()
	{
		ItemContainer bankContainer = client.getItemContainer(InventoryID.BANK);
		if (bankContainer != null)
		{
			log.info("Checking bank for new items...");
			int newUnlocks = 0;
			for (Item item : bankContainer.getItems())
			{
				if (item.getId() > 0 && checkAndUnlockItem(item.getId()))
				{
					newUnlocks++;
				}
			}
			if (newUnlocks > 0)
			{
				log.info("Unlocked {} new items from bank", newUnlocks);
			}
		}
	}

	private boolean checkAndUnlockItem(int itemId)
	{
		// Ignore placeholder items and invalid IDs
		if (itemId <= 0 || itemId == 799) // 799 is a placeholder
		{
			return false;
		}

		// Check if already unlocked
		if (unlockTracker.isUnlocked(itemId))
		{
			return false;
		}

		// Check if we've already processed this item
		if (pendingUnlocks.contains(itemId))
		{
			return false;
		}

		// Get item name
		ItemComposition itemComp = itemManager.getItemComposition(itemId);
		String itemName = itemComp.getName();

		// Unlock the item
		if (unlockTracker.unlockItem(itemId, itemName))
		{
			pendingUnlocks.add(itemId);

			// Show notification if enabled
			if (config.enableUnlockNotifications())
			{
				client.addChatMessage(ChatMessageType.GAMEMESSAGE, "",
					"<col=ef20ff>New item unlocked: " + itemName + "!</col>",
					null);
			}

			// Post to Discord
			postUnlockToDiscord(itemId, itemName);

			return true;
		}

		return false;
	}

	private void postUnlockToDiscord(int itemId, String itemName)
	{
		if (discordClient == null)
		{
			log.warn("Discord client not initialized");
			return;
		}

		String playerName = client.getLocalPlayer() != null ?
			client.getLocalPlayer().getName() : "Unknown";

		executor.submit(() -> {
			boolean success = discordClient.postUnlock(playerName, itemId, itemName);
			if (success)
			{
				log.info("Posted unlock to Discord: {}", itemName);
			}
		});
	}

	private void syncFromDiscord()
	{
		if (discordClient == null)
		{
			updateDiscordClient();
		}

		if (discordClient == null)
		{
			log.debug("Skipping Discord sync - client not configured");
			return;
		}

		String channelId = config.channelId();
		if (channelId.isEmpty())
		{
			log.debug("Skipping Discord sync - channel ID not configured");
			return;
		}

		executor.submit(() -> {
			try
			{
				log.info("Syncing unlocks from Discord...");
				List<DiscordClient.UnlockMessage> messages = discordClient.fetchUnlocks(channelId, 100);
				int newUnlocks = unlockTracker.unlockItems(messages);

				if (newUnlocks > 0)
				{
					log.info("Synced {} new unlocks from Discord", newUnlocks);

					if (config.enableUnlockNotifications() && client.getGameState() == GameState.LOGGED_IN)
					{
						clientThread.invoke(() -> {
							client.addChatMessage(ChatMessageType.GAMEMESSAGE, "",
								"<col=ef20ff>Synced " + newUnlocks + " new unlock(s) from group!</col>",
								null);
						});
					}
				}
				else
				{
					log.info("No new unlocks found during sync");
				}
			}
			catch (Exception e)
			{
				log.error("Error syncing from Discord", e);
			}
		});
	}

	private void updateDiscordClient()
	{
		String botToken = config.botToken();
		String webhookUrl = config.webhookUrl();

		if (!botToken.isEmpty() || !webhookUrl.isEmpty())
		{
			discordClient = new DiscordClient(botToken, webhookUrl);
			log.info("Discord client initialized");
		}
		else
		{
			log.warn("Discord not configured - check plugin settings");
		}
	}

	private boolean isGrandExchangeOffer(MenuOptionClicked event)
	{
		// Check if this is a GE buy/sell offer
		String option = Text.removeTags(event.getMenuOption()).toLowerCase();
		return (option.contains("buy") || option.contains("offer")) &&
			event.getWidget() != null &&
			(event.getWidgetId() == WidgetInfo.GRAND_EXCHANGE_OFFER_CONTAINER.getId() ||
			 event.getWidgetId() == WidgetInfo.GRAND_EXCHANGE_WINDOW_CONTAINER.getId());
	}

	private int getItemIdFromMenuEntry(MenuOptionClicked event)
	{
		// Extract item ID from the menu entry
		if (event.getWidget() != null)
		{
			Widget widget = event.getWidget();
			if (widget.getItemId() > 0)
			{
				return widget.getItemId();
			}
		}
		return event.getId();
	}

	@Provides
	ExampleConfig provideConfig(ConfigManager configManager)
	{
		return configManager.getConfig(ExampleConfig.class);
	}
}

