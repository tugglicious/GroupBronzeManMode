package com.example;

import net.runelite.client.config.Config;
import net.runelite.client.config.ConfigGroup;
import net.runelite.client.config.ConfigItem;
import net.runelite.client.config.ConfigSection;

@ConfigGroup("gbmm")
public interface ExampleConfig extends Config
{
	@ConfigSection(
		name = "Discord Settings",
		description = "Discord bot and webhook configuration",
		position = 0
	)
	String discordSection = "discord";

	@ConfigItem(
		keyName = "botToken",
		name = "Bot Token",
		description = "Your Discord bot token for reading messages",
		section = discordSection,
		position = 0
	)
	default String botToken()
	{
		return "";
	}

	@ConfigItem(
		keyName = "webhookUrl",
		name = "Webhook URL",
		description = "Discord webhook URL for posting unlocks",
		section = discordSection,
		position = 1
	)
	default String webhookUrl()
	{
		return "";
	}

	@ConfigItem(
		keyName = "channelId",
		name = "Channel ID",
		description = "Discord channel ID to monitor for unlocks",
		section = discordSection,
		position = 2
	)
	default String channelId()
	{
		return "";
	}

	@ConfigSection(
		name = "Group Settings",
		description = "Group bronzeman mode settings",
		position = 1
	)
	String groupSection = "group";

	@ConfigItem(
		keyName = "groupName",
		name = "Group Name",
		description = "Your group's name (optional)",
		section = groupSection,
		position = 0
	)
	default String groupName()
	{
		return "My Group";
	}

	@ConfigItem(
		keyName = "enableUnlockNotifications",
		name = "Enable Unlock Notifications",
		description = "Show in-game notifications when items are unlocked",
		section = groupSection,
		position = 1
	)
	default boolean enableUnlockNotifications()
	{
		return true;
	}

	@ConfigItem(
		keyName = "syncInterval",
		name = "Sync Interval (minutes)",
		description = "How often to sync unlocks from Discord (1-60 minutes)",
		section = groupSection,
		position = 2
	)
	default int syncInterval()
	{
		return 5;
	}
}
