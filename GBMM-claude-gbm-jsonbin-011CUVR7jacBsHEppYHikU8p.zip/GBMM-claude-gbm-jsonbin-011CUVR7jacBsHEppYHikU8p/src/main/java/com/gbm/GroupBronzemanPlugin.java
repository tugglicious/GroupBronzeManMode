package com.gbm;

import com.google.inject.Provides;
import lombok.extern.slf4j.Slf4j;
import net.runelite.api.*;
import net.runelite.api.events.*;
import net.runelite.api.widgets.Widget;
import net.runelite.api.widgets.WidgetInfo;
import net.runelite.client.callback.ClientThread;
import net.runelite.client.config.ConfigManager;
import net.runelite.client.eventbus.Subscribe;
import net.runelite.client.game.ItemManager;
import net.runelite.client.plugins.Plugin;
import net.runelite.client.plugins.PluginDescriptor;
import net.runelite.client.util.Text;

import javax.inject.Inject;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

@Slf4j
@PluginDescriptor(
	name = "Group Bronzeman Mode",
	description = "Group Bronzeman Mode - unlock items together with JSONBin.io!",
	tags = {"bronzeman", "group", "ironman", "jsonbin"}
)
public class GroupBronzemanPlugin extends Plugin
{
	@Inject
	private Client client;

	@Inject
	private GroupBronzemanConfig config;

	@Inject
	private ConfigManager configManager;

	@Inject
	private ItemManager itemManager;

	@Inject
	private ClientThread clientThread;

	@Inject
	private ScheduledExecutorService executor;

	private JsonBinClient jsonBinClient;
	private UnlockTracker unlockTracker;
	private ScheduledFuture<?> syncTask;
	private final Set<Integer> processedItems = new HashSet<>();

	@Override
	protected void startUp() throws Exception
	{
		log.info("Group Bronzeman Mode started!");

		// Initialize JSONBin client
		updateJsonBinClient();

		// Initialize unlock tracker
		unlockTracker = new UnlockTracker(jsonBinClient);

		// Perform initial sync from JSONBin
		syncFromRemote();

		// Schedule periodic sync if auto-sync is enabled
		if (config.autoSync())
		{
			scheduleSync();
		}
	}

	@Override
	protected void shutDown() throws Exception
	{
		log.info("Group Bronzeman Mode stopped!");

		// Push any pending unlocks before shutting down
		if (unlockTracker != null && unlockTracker.hasPendingPush())
		{
			log.info("Pushing pending unlocks before shutdown...");
			unlockTracker.pushToRemote();
		}

		// Cancel sync task
		if (syncTask != null && !syncTask.isCancelled())
		{
			syncTask.cancel(false);
		}

		jsonBinClient = null;
		unlockTracker = null;
		processedItems.clear();
	}

	@Subscribe
	public void onItemContainerChanged(ItemContainerChanged event)
	{
		// Check inventory and equipment for new items
		if (event.getContainerId() == InventoryID.INVENTORY.getId() ||
			event.getContainerId() == InventoryID.EQUIPMENT.getId())
		{
			ItemContainer container = event.getItemContainer();
			if (container != null)
			{
				for (Item item : container.getItems())
				{
					checkAndUnlockItem(item.getId());
				}
			}
		}
	}

	@Subscribe
	public void onWidgetLoaded(WidgetLoaded event)
	{
		// Check bank when it's opened
		if (event.getGroupId() == WidgetInfo.BANK_ITEM_CONTAINER.getGroupId())
		{
			clientThread.invokeLater(this::checkBankItems);
		}
	}

	@Subscribe
	public void onMenuOptionClicked(MenuOptionClicked event)
	{
		// Block Grand Exchange offers for locked items
		if (isGrandExchangeOffer(event))
		{
			int itemId = getItemIdFromMenuEntry(event);
			if (itemId > 0 && !unlockTracker.isUnlocked(itemId))
			{
				event.consume();

				String itemName = itemManager.getItemComposition(itemId).getName();
				client.addChatMessage(ChatMessageType.GAMEMESSAGE, "",
					"You cannot buy <col=ef1020>" + itemName + "</col> - you haven't unlocked it yet!",
					null);
			}
		}
	}

	private void checkBankItems()
	{
		ItemContainer bankContainer = client.getItemContainer(InventoryID.BANK);
		if (bankContainer != null)
		{
			log.info("Checking bank for new items...");
			int newUnlocks = 0;
			for (Item item : bankContainer.getItems())
			{
				if (item.getId() > 0 && checkAndUnlockItem(item.getId()))
				{
					newUnlocks++;
				}
			}
			if (newUnlocks > 0)
			{
				log.info("Unlocked {} new items from bank", newUnlocks);
				// Push new unlocks to JSONBin
				pushToRemote();
			}
		}
	}

	private boolean checkAndUnlockItem(int itemId)
	{
		// Ignore placeholder items and invalid IDs
		if (itemId <= 0 || itemId == 799) // 799 is a placeholder
		{
			return false;
		}

		// Check if already unlocked
		if (unlockTracker.isUnlocked(itemId))
		{
			return false;
		}

		// Check if we've already processed this item this session
		if (processedItems.contains(itemId))
		{
			return false;
		}

		// Get item name
		ItemComposition itemComp = itemManager.getItemComposition(itemId);
		String itemName = itemComp.getName();

		// Get player name
		String playerName = client.getLocalPlayer() != null ?
			client.getLocalPlayer().getName() : "Unknown";

		// Unlock the item
		if (unlockTracker.unlockItem(itemId, itemName, playerName))
		{
			processedItems.add(itemId);

			// Show notification if enabled
			if (config.enableUnlockNotifications())
			{
				String message = config.showWhoUnlocked() ?
					String.format("<col=ef20ff>New item unlocked: %s (by you)!</col>", itemName) :
					String.format("<col=ef20ff>New item unlocked: %s!</col>", itemName);

				client.addChatMessage(ChatMessageType.GAMEMESSAGE, "", message, null);
			}

			// Schedule push to JSONBin
			executor.schedule(this::pushToRemote, 2, TimeUnit.SECONDS);

			return true;
		}

		return false;
	}

	private void pushToRemote()
	{
		if (unlockTracker == null || jsonBinClient == null)
		{
			return;
		}

		executor.submit(() -> {
			try
			{
				if (unlockTracker.hasPendingPush())
				{
					log.info("Pushing unlocks to JSONBin...");
					boolean success = unlockTracker.pushToRemote();
					if (success)
					{
						log.info("Successfully pushed unlocks to JSONBin");
					}
					else
					{
						log.warn("Failed to push unlocks to JSONBin");
					}
				}
			}
			catch (Exception e)
			{
				log.error("Error pushing to JSONBin", e);
			}
		});
	}

	private void syncFromRemote()
	{
		if (unlockTracker == null || jsonBinClient == null)
		{
			log.debug("Skipping sync - client not configured");
			return;
		}

		executor.submit(() -> {
			try
			{
				log.info("Syncing unlocks from JSONBin...");
				int newUnlocks = unlockTracker.syncFromRemote();

				if (newUnlocks > 0)
				{
					log.info("Synced {} new unlocks from JSONBin", newUnlocks);

					if (config.enableUnlockNotifications() && client.getGameState() == GameState.LOGGED_IN)
					{
						clientThread.invoke(() -> {
							client.addChatMessage(ChatMessageType.GAMEMESSAGE, "",
								"<col=ef20ff>Synced " + newUnlocks + " new unlock(s) from group!</col>",
								null);
						});
					}
				}
				else
				{
					log.info("No new unlocks found during sync");
				}
			}
			catch (Exception e)
			{
				log.error("Error syncing from JSONBin", e);
			}
		});
	}

	private void updateJsonBinClient()
	{
		String apiKey = config.apiKey();
		String binId = config.binId();

		if (!apiKey.isEmpty() && !binId.isEmpty())
		{
			jsonBinClient = new JsonBinClient(apiKey, binId);
			log.info("JSONBin client initialized");
		}
		else
		{
			log.warn("JSONBin not configured - check plugin settings");
		}
	}

	private void scheduleSync()
	{
		if (syncTask != null && !syncTask.isCancelled())
		{
			syncTask.cancel(false);
		}

		int syncMinutes = Math.max(1, Math.min(60, config.syncInterval()));
		syncTask = executor.scheduleAtFixedRate(this::syncFromRemote, syncMinutes, syncMinutes, TimeUnit.MINUTES);
		log.info("Scheduled sync every {} minutes", syncMinutes);
	}

	private boolean isGrandExchangeOffer(MenuOptionClicked event)
	{
		// Check if this is a GE buy/sell offer
		String option = Text.removeTags(event.getMenuOption()).toLowerCase();
		return (option.contains("buy") || option.contains("offer")) &&
			event.getWidget() != null &&
			(event.getWidgetId() == WidgetInfo.GRAND_EXCHANGE_OFFER_CONTAINER.getId() ||
			 event.getWidgetId() == WidgetInfo.GRAND_EXCHANGE_WINDOW_CONTAINER.getId());
	}

	private int getItemIdFromMenuEntry(MenuOptionClicked event)
	{
		// Extract item ID from the menu entry
		if (event.getWidget() != null)
		{
			Widget widget = event.getWidget();
			if (widget.getItemId() > 0)
			{
				return widget.getItemId();
			}
		}
		return event.getId();
	}

	@Provides
	GroupBronzemanConfig provideConfig(ConfigManager configManager)
	{
		return configManager.getConfig(GroupBronzemanConfig.class);
	}
}
