package com.gbm;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeUnit;

@Slf4j
public class JsonBinClient
{
	private static final String JSONBIN_API_BASE = "https://api.jsonbin.io/v3";
	private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");

	private final OkHttpClient httpClient;
	private final Gson gson;
	private final String apiKey;
	private final String binId;

	public JsonBinClient(String apiKey, String binId)
	{
		this.apiKey = apiKey;
		this.binId = binId;
		this.gson = new Gson();

		this.httpClient = new OkHttpClient.Builder()
			.connectTimeout(10, TimeUnit.SECONDS)
			.readTimeout(10, TimeUnit.SECONDS)
			.writeTimeout(10, TimeUnit.SECONDS)
			.build();
	}

	/**
	 * Fetch all unlocks from JSONBin
	 */
	public UnlockData fetchUnlocks()
	{
		if (apiKey == null || apiKey.isEmpty() || binId == null || binId.isEmpty())
		{
			log.warn("JSONBin not configured (missing API key or Bin ID)");
			return new UnlockData();
		}

		try
		{
			String url = String.format("%s/b/%s/latest", JSONBIN_API_BASE, binId);

			Request request = new Request.Builder()
				.url(url)
				.header("X-Master-Key", apiKey)
				.get()
				.build();

			try (Response response = httpClient.newCall(request).execute())
			{
				if (!response.isSuccessful())
				{
					log.error("Failed to fetch from JSONBin: {} - {}", response.code(), response.message());
					return new UnlockData();
				}

				String responseBody = response.body().string();
				JsonObject jsonResponse = gson.fromJson(responseBody, JsonObject.class);

				// JSONBin returns data in a "record" field
				if (jsonResponse.has("record"))
				{
					UnlockData data = gson.fromJson(jsonResponse.get("record"), UnlockData.class);
					log.info("Fetched {} unlocks from JSONBin", data.unlockedItems.size());
					return data;
				}
				else
				{
					log.warn("No 'record' field in JSONBin response");
					return new UnlockData();
				}
			}
		}
		catch (IOException e)
		{
			log.error("Error fetching from JSONBin", e);
			return new UnlockData();
		}
	}

	/**
	 * Push unlocks to JSONBin
	 */
	public boolean pushUnlocks(UnlockData data)
	{
		if (apiKey == null || apiKey.isEmpty() || binId == null || binId.isEmpty())
		{
			log.warn("JSONBin not configured (missing API key or Bin ID)");
			return false;
		}

		try
		{
			String url = String.format("%s/b/%s", JSONBIN_API_BASE, binId);

			String json = gson.toJson(data);
			RequestBody body = RequestBody.create(JSON, json);

			Request request = new Request.Builder()
				.url(url)
				.header("X-Master-Key", apiKey)
				.header("Content-Type", "application/json")
				.put(body)
				.build();

			try (Response response = httpClient.newCall(request).execute())
			{
				if (response.isSuccessful())
				{
					log.info("Successfully pushed {} unlocks to JSONBin", data.unlockedItems.size());
					return true;
				}
				else
				{
					log.error("Failed to push to JSONBin: {} - {}", response.code(), response.message());
					return false;
				}
			}
		}
		catch (IOException e)
		{
			log.error("Error pushing to JSONBin", e);
			return false;
		}
	}

	/**
	 * Data structure for unlocks stored in JSONBin
	 */
	public static class UnlockData
	{
		public Map<Integer, UnlockEntry> unlockedItems;
		public long lastUpdated;

		public UnlockData()
		{
			this.unlockedItems = new HashMap<>();
			this.lastUpdated = System.currentTimeMillis();
		}

		public void addUnlock(int itemId, String itemName, String playerName)
		{
			if (!unlockedItems.containsKey(itemId))
			{
				unlockedItems.put(itemId, new UnlockEntry(itemName, playerName, System.currentTimeMillis()));
				lastUpdated = System.currentTimeMillis();
			}
		}

		public boolean isUnlocked(int itemId)
		{
			return unlockedItems.containsKey(itemId);
		}

		public Set<Integer> getItemIds()
		{
			return unlockedItems.keySet();
		}
	}

	/**
	 * Individual unlock entry
	 */
	public static class UnlockEntry
	{
		public String itemName;
		public String unlockedBy;
		public long timestamp;

		public UnlockEntry(String itemName, String unlockedBy, long timestamp)
		{
			this.itemName = itemName;
			this.unlockedBy = unlockedBy;
			this.timestamp = timestamp;
		}
	}
}
