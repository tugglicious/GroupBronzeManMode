package com.gbm;

import net.runelite.client.config.Config;
import net.runelite.client.config.ConfigGroup;
import net.runelite.client.config.ConfigItem;
import net.runelite.client.config.ConfigSection;

@ConfigGroup("groupbronzeman")
public interface GroupBronzemanConfig extends Config
{
	@ConfigSection(
		name = "JSONBin Settings",
		description = "JSONBin.io configuration for group sync",
		position = 0
	)
	String jsonbinSection = "jsonbin";

	@ConfigItem(
		keyName = "apiKey",
		name = "API Key",
		description = "Your JSONBin.io API key (X-Master-Key)",
		section = jsonbinSection,
		position = 0
	)
	default String apiKey()
	{
		return "";
	}

	@ConfigItem(
		keyName = "binId",
		name = "Bin ID",
		description = "Your JSONBin.io Bin ID (the unique ID for your group's storage)",
		section = jsonbinSection,
		position = 1
	)
	default String binId()
	{
		return "";
	}

	@ConfigSection(
		name = "Group Settings",
		description = "Group bronzeman mode settings",
		position = 1
	)
	String groupSection = "group";

	@ConfigItem(
		keyName = "groupName",
		name = "Group Name",
		description = "Your group's name (optional)",
		section = groupSection,
		position = 0
	)
	default String groupName()
	{
		return "My Group";
	}

	@ConfigItem(
		keyName = "enableUnlockNotifications",
		name = "Enable Unlock Notifications",
		description = "Show in-game notifications when items are unlocked",
		section = groupSection,
		position = 1
	)
	default boolean enableUnlockNotifications()
	{
		return true;
	}

	@ConfigItem(
		keyName = "syncInterval",
		name = "Sync Interval (minutes)",
		description = "How often to sync unlocks from JSONBin (1-60 minutes)",
		section = groupSection,
		position = 2
	)
	default int syncInterval()
	{
		return 5;
	}

	@ConfigItem(
		keyName = "autoSync",
		name = "Auto Sync",
		description = "Automatically sync with JSONBin periodically",
		section = groupSection,
		position = 3
	)
	default boolean autoSync()
	{
		return true;
	}

	@ConfigItem(
		keyName = "showWhoUnlocked",
		name = "Show Who Unlocked",
		description = "Show which player unlocked each item",
		section = groupSection,
		position = 4
	)
	default boolean showWhoUnlocked()
	{
		return true;
	}
}
