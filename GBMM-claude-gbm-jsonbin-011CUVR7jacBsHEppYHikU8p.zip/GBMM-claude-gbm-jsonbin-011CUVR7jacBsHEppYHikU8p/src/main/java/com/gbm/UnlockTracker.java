package com.gbm;

import lombok.extern.slf4j.Slf4j;

import java.util.*;

@Slf4j
public class UnlockTracker
{
	private final JsonBinClient jsonBinClient;
	private JsonBinClient.UnlockData localUnlocks;
	private final Set<Integer> pendingPush; // Items we've unlocked but haven't pushed yet

	public UnlockTracker(JsonBinClient jsonBinClient)
	{
		this.jsonBinClient = jsonBinClient;
		this.localUnlocks = new JsonBinClient.UnlockData();
		this.pendingPush = new HashSet<>();
	}

	/**
	 * Check if an item is unlocked
	 */
	public boolean isUnlocked(int itemId)
	{
		return localUnlocks.isUnlocked(itemId);
	}

	/**
	 * Unlock an item locally (returns true if this is a new unlock)
	 */
	public boolean unlockItem(int itemId, String itemName, String playerName)
	{
		if (!localUnlocks.isUnlocked(itemId))
		{
			localUnlocks.addUnlock(itemId, itemName, playerName);
			pendingPush.add(itemId);
			log.info("New item unlocked: {} (ID: {}) by {}", itemName, itemId, playerName);
			return true;
		}
		return false;
	}

	/**
	 * Sync from JSONBin - fetch remote data and merge with local
	 */
	public int syncFromRemote()
	{
		if (jsonBinClient == null)
		{
			log.warn("JSONBin client not initialized");
			return 0;
		}

		JsonBinClient.UnlockData remoteData = jsonBinClient.fetchUnlocks();
		if (remoteData == null)
		{
			log.warn("Failed to fetch remote unlocks");
			return 0;
		}

		int newUnlocks = 0;
		for (Map.Entry<Integer, JsonBinClient.UnlockEntry> entry : remoteData.unlockedItems.entrySet())
		{
			int itemId = entry.getKey();
			JsonBinClient.UnlockEntry unlockEntry = entry.getValue();

			if (!localUnlocks.isUnlocked(itemId))
			{
				localUnlocks.addUnlock(itemId, unlockEntry.itemName, unlockEntry.unlockedBy);
				newUnlocks++;
			}
		}

		if (newUnlocks > 0)
		{
			log.info("Synced {} new unlocks from remote", newUnlocks);
		}

		return newUnlocks;
	}

	/**
	 * Push local unlocks to JSONBin
	 */
	public boolean pushToRemote()
	{
		if (jsonBinClient == null)
		{
			log.warn("JSONBin client not initialized");
			return false;
		}

		if (pendingPush.isEmpty())
		{
			log.debug("No pending unlocks to push");
			return true;
		}

		// First sync from remote to avoid overwriting others' unlocks
		JsonBinClient.UnlockData remoteData = jsonBinClient.fetchUnlocks();
		if (remoteData != null)
		{
			// Merge remote data into local
			for (Map.Entry<Integer, JsonBinClient.UnlockEntry> entry : remoteData.unlockedItems.entrySet())
			{
				int itemId = entry.getKey();
				JsonBinClient.UnlockEntry remoteEntry = entry.getValue();

				if (!localUnlocks.isUnlocked(itemId))
				{
					localUnlocks.addUnlock(itemId, remoteEntry.itemName, remoteEntry.unlockedBy);
				}
			}
		}

		// Now push merged data
		boolean success = jsonBinClient.pushUnlocks(localUnlocks);
		if (success)
		{
			pendingPush.clear();
			log.info("Successfully pushed unlocks to remote");
		}

		return success;
	}

	/**
	 * Get all unlocked item IDs
	 */
	public Set<Integer> getUnlockedItems()
	{
		return new HashSet<>(localUnlocks.getItemIds());
	}

	/**
	 * Get the name of an unlocked item
	 */
	public String getItemName(int itemId)
	{
		JsonBinClient.UnlockEntry entry = localUnlocks.unlockedItems.get(itemId);
		return entry != null ? entry.itemName : "Unknown Item";
	}

	/**
	 * Get count of unlocked items
	 */
	public int getUnlockCount()
	{
		return localUnlocks.unlockedItems.size();
	}

	/**
	 * Check if there are pending unlocks to push
	 */
	public boolean hasPendingPush()
	{
		return !pendingPush.isEmpty();
	}
}
