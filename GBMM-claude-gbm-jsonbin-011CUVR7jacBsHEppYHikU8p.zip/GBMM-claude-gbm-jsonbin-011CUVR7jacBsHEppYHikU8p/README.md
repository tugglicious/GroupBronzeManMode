# Group Bronzeman Mode (GBM)

A RuneLite plugin that brings Group Bronzeman Mode to Old School RuneScape using JSONBin.io for easy synchronization!

## What is Group Bronzeman Mode?

Group Bronzeman Mode is a community gamemode where you and your friends share item unlocks:
- **Can't buy items from GE** until someone in your group obtains them first
- **Unlock items** by obtaining them through drops, shops, quests, etc.
- **Syncs via JSONBin.io** - when anyone unlocks an item, everyone gets it
- **Super easy setup** - no complicated cloud infrastructure or bot configuration

## Why JSONBin.io?

Unlike other group bronzeman implementations that require Azure setup or Discord bots:
- ✅ **5-minute setup** - Just create account, get API key, create bin
- ✅ **Free** - Generous free tier perfect for group play
- ✅ **Simple** - Only 2 things to configure (API key + Bin ID)
- ✅ **Reliable** - Purpose-built JSON storage service
- ✅ **No maintenance** - No servers to manage

## Features

✅ **Automatic Item Unlocking** - Detects items from inventory, bank, and equipment
✅ **Grand Exchange Restrictions** - Blocks buying items you haven't unlocked
✅ **JSONBin.io Integration** - Simple, reliable group synchronization
✅ **In-game Notifications** - Shows messages when items are unlocked
✅ **Auto Sync** - Periodically syncs unlocks from your group
✅ **Track Who Unlocked** - See which player unlocked each item
✅ **Smart Merging** - Prevents overwriting group members' unlocks

## Quick Start

### 1. Setup JSONBin.io (5 minutes)

Follow the detailed guide in [JSONBIN_SETUP_GUIDE.md](JSONBIN_SETUP_GUIDE.md):
1. Create free account at https://jsonbin.io/
2. Get your API key (X-Master-Key)
3. Create a bin
4. Copy the Bin ID

### 2. Install the Plugin

```bash
# Build the plugin
./gradlew build

# Copy to RuneLite plugins folder
cp build/libs/*.jar ~/.runelite/plugins/

# Restart RuneLite
```

### 3. Configure in RuneLite

1. Open RuneLite
2. Click **Configuration** (wrench icon)
3. Search for **"Group Bronzeman Mode"**
4. Enter your **API Key** and **Bin ID**
5. Configure group settings as desired

### 4. Share with Your Group

All group members need the **same**:
- API Key
- Bin ID

⚠️ Share these privately with your group members!

## How It Works

### When You Unlock an Item

1. Plugin detects item in inventory/bank/equipment
2. Checks if it's a new unlock
3. Saves locally
4. Immediately pushes to JSONBin.io
5. Shows in-game notification

### Syncing from Group

1. Plugin periodically fetches data from JSONBin (every 5 minutes by default)
2. Merges any new unlocks from group members
3. Updates your local unlock list
4. Shows notification if new items were synced

### Grand Exchange Restriction

1. You try to buy an item on GE
2. Plugin checks if item is unlocked
3. If locked, blocks the offer and shows message
4. If unlocked, allows the purchase

## Configuration Options

### JSONBin Settings
| Setting | Description | Required |
|---------|-------------|----------|
| API Key | Your JSONBin.io X-Master-Key | Yes |
| Bin ID | Your group's Bin ID | Yes |

### Group Settings
| Setting | Description | Default |
|---------|-------------|---------|
| Group Name | Your group's name (cosmetic) | "My Group" |
| Enable Unlock Notifications | Show in-game messages | Enabled |
| Sync Interval | How often to sync (minutes) | 5 |
| Auto Sync | Automatically sync periodically | Enabled |
| Show Who Unlocked | Show player name in notifications | Enabled |

## Initial Setup

When you first enable the plugin:

1. **Open your bank** - This will unlock all items you currently have
2. Wait for sync - Plugin will push your unlocks to JSONBin
3. Verify - Check https://jsonbin.io/ to see your data

## Commands & Tips

### Force Sync
Restart the plugin to force an immediate sync

### View Your Unlocks
Check the RuneLite logs or visit your bin at https://jsonbin.io/

### Multiple Groups
Create separate bins for different groups and switch between them by changing the Bin ID in config

## Comparison with Other Implementations

| Feature | GBM (JSONBin) | Crabman (Azure) | Discord Version |
|---------|---------------|-----------------|-----------------|
| Setup Time | 5 minutes | 30+ minutes | 15 minutes |
| External Service | JSONBin.io | Azure Tables | Discord Bot |
| Configuration | API Key + Bin ID | Connection String + Multiple Settings | Bot Token + Webhook + Channel |
| Free Tier | Yes, generous | Yes, limited | Yes |
| Ease of Use | ⭐⭐⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐ |
| Reliability | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ |

## Troubleshooting

### Items Not Syncing

**Check:**
1. API Key and Bin ID are correct
2. All group members use the same credentials
3. Auto Sync is enabled
4. Internet connection is working
5. Check RuneLite logs for errors

**Fix:**
- Verify credentials at https://jsonbin.io/
- Restart the plugin to force sync
- Check your bin on the website to see if data is being stored

### Can't Buy on GE

This is intentional! You can only buy items that have been unlocked by your group.

**To unlock an item:**
- Obtain it through drops, shops, quests, etc.
- Have any group member obtain it first

### Failed to Push/Fetch

**Possible causes:**
- Incorrect credentials
- Network issues
- Rate limiting (rare)

**Solution:**
1. Double-check API Key and Bin ID
2. Check internet connection
3. Wait a few minutes and try again
4. Check JSONBin.io dashboard for any alerts

## Technical Details

### Architecture

```
Plugin Components:
├── GroupBronzemanPlugin.java  - Main plugin logic & event handlers
├── GroupBronzemanConfig.java  - Configuration interface
├── JsonBinClient.java         - JSONBin.io API integration
└── UnlockTracker.java         - Unlock management & sync logic

Data Flow:
1. Player gets item → Unlock locally → Push to JSONBin
2. Periodic sync → Fetch from JSONBin → Merge unlocks → Update local
3. GE interaction → Check if unlocked → Allow/Block
```

### Data Structure

```json
{
  "unlockedItems": {
    "itemId": {
      "itemName": "Bronze sword",
      "unlockedBy": "PlayerName",
      "timestamp": 1234567890
    }
  },
  "lastUpdated": 1234567890
}
```

### Dependencies

- **OkHttp** - HTTP client for JSONBin API
- **Gson** - JSON serialization
- **RuneLite API** - Game integration

### API Calls

- **Fetch**: `GET https://api.jsonbin.io/v3/b/{binId}/latest`
- **Push**: `PUT https://api.jsonbin.io/v3/b/{binId}`

Both require `X-Master-Key` header with your API key.

## Development

### Building

```bash
./gradlew build
```

### Testing

```bash
./gradlew test
```

### Creating Shadow JAR

```bash
./gradlew shadowJar
```

## Privacy & Security

⚠️ **Important Security Notes:**

1. **Never share your API key publicly**
2. **Only share with trusted group members**
3. **Anyone with your credentials can modify your unlocks**
4. **Use private communication to share credentials**

If your credentials are compromised:
1. Create a new bin on JSONBin.io
2. Get a new Bin ID
3. Share new credentials with your group

## Contributing

Contributions welcome! Feel free to:
- Report bugs
- Suggest features
- Submit pull requests

## Credits

- Created for Group Bronzeman Mode players
- Inspired by existing bronzeman plugins
- Uses JSONBin.io for simple, reliable synchronization

## License

See LICENSE file for details.

## Support

Having issues?

1. Check [JSONBIN_SETUP_GUIDE.md](JSONBIN_SETUP_GUIDE.md) for setup help
2. Check RuneLite logs for error messages
3. Visit your bin at https://jsonbin.io/ to verify data
4. Try the troubleshooting steps above

## Links

- JSONBin.io: https://jsonbin.io/
- RuneLite: https://runelite.net/
- OSRS Wiki: https://oldschool.runescape.wiki/

## Disclaimer

This is a third-party plugin for RuneLite. Use at your own risk. Always follow Jagex's game rules and terms of service.

---

Happy scaping with your group! 🎉
