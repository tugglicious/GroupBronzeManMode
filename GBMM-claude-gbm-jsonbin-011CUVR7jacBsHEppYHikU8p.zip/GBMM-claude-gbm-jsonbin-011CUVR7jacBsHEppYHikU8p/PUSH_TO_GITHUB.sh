#!/bin/bash

# Script to push GBM to GitHub
# Run this on your local machine after copying the repository

echo "=== Pushing GBM to GitHub ==="
echo ""

# Set the repository URL
REPO_URL="https://github.com/tugglicious/GBM.git"

echo "Step 1: Setting remote to GitHub..."
git remote remove origin 2>/dev/null
git remote add origin $REPO_URL

echo ""
echo "Step 2: Verifying remote..."
git remote -v

echo ""
echo "Step 3: Pushing to GitHub..."
git push -u origin main

echo ""
echo "✅ Done! Visit https://github.com/tugglicious/GBM to see your repository"
