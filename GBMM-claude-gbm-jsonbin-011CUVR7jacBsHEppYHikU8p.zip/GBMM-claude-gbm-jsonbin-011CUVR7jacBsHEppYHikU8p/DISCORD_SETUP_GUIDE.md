# Discord Setup Guide for Group Bronzeman Mode

This guide will walk you through setting up Discord for your Group Bronzeman Mode plugin.

## Part 1: Create a Discord Bot

### Step 1: Go to Discord Developer Portal
1. Visit https://discord.com/developers/applications
2. Log in with your Discord account
3. Click **"New Application"** button (top right)
4. Name it something like "GBMM Bot" and click **Create**

### Step 2: Create the Bot
1. In the left sidebar, click **"Bot"**
2. Click **"Add Bot"** and confirm
3. Under the bot's username, click **"Reset Token"** and then **"Copy"**
4. **SAVE THIS TOKEN** - You'll need it for the plugin configuration
   - ⚠️ **NEVER share this token publicly!**

### Step 3: Enable Required Intents
1. Scroll down to **"Privileged Gateway Intents"**
2. Enable **"MESSAGE CONTENT INTENT"**
3. Click **"Save Changes"**

### Step 4: Invite Bot to Your Server
1. In the left sidebar, click **"OAuth2"** → **"URL Generator"**
2. Under **SCOPES**, check:
   - `bot`
3. Under **BOT PERMISSIONS**, check:
   - `Read Messages/View Channels`
   - `Read Message History`
4. Copy the generated URL at the bottom
5. Paste it in your browser and select your server
6. Click **"Authorize"**

## Part 2: Create a Webhook

### Step 1: Open Discord Server Settings
1. Right-click your Discord server icon
2. Click **"Server Settings"**
3. Click **"Integrations"** in the left sidebar

### Step 2: Create Webhook
1. Click **"Webhooks"** or **"Create Webhook"**
2. Click **"New Webhook"**
3. Name it something like "GBMM Unlocks"
4. Select the channel where unlocks should be posted
5. Click **"Copy Webhook URL"**
6. **SAVE THIS URL** - You'll need it for the plugin configuration

## Part 3: Get Channel ID

### Step 1: Enable Developer Mode
1. Open Discord User Settings (gear icon)
2. Go to **"Advanced"** (under App Settings)
3. Enable **"Developer Mode"**

### Step 2: Copy Channel ID
1. Right-click the channel where unlocks are posted
2. Click **"Copy Channel ID"**
3. **SAVE THIS ID** - You'll need it for the plugin configuration

## Part 4: Configure the Plugin

Once you have:
- ✅ Bot Token
- ✅ Webhook URL
- ✅ Channel ID

You'll enter these in the RuneLite plugin settings:

1. Open RuneLite
2. Click the **Configuration** wrench icon (top right)
3. Search for **"GBMM"** or **"Group Bronzeman"**
4. Enter your:
   - **Bot Token**
   - **Webhook URL**
   - **Channel ID**
   - **Group Name** (optional, for identifying your group)

## Security Notes

⚠️ **IMPORTANT**:
- Never share your bot token publicly
- Never commit tokens to GitHub
- Each group member needs the same bot token, webhook URL, and channel ID
- Anyone with these credentials can read/write to your group's unlocks

## Troubleshooting

**Bot can't read messages:**
- Make sure "MESSAGE CONTENT INTENT" is enabled
- Verify bot has "Read Message History" permission in the channel

**Webhook not posting:**
- Verify the webhook URL is correct
- Check the channel still exists
- Make sure webhook wasn't deleted

**Rate limiting:**
- Discord has rate limits (typically 50 requests per second)
- Normal gameplay shouldn't hit these limits
- If you do, the plugin will automatically retry

## For Group Members

Share these with your group (via a secure method):
1. Bot Token: `[PASTE TOKEN HERE]`
2. Webhook URL: `[PASTE URL HERE]`
3. Channel ID: `[PASTE ID HERE]`

Everyone in your group needs to use the same values.
