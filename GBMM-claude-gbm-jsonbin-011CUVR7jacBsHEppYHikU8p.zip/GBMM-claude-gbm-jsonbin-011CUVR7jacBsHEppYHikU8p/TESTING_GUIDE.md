# Testing RuneLite Plugins - Development Guide

## Method 1: IntelliJ IDEA Setup (RECOMMENDED)

This is the standard development workflow for RuneLite plugins.

### Prerequisites

1. **IntelliJ IDEA Community Edition** (free)
   - Download: https://www.jetbrains.com/idea/download/

2. **Java 11 JDK** (Eclipse Temurin recommended)
   - Download: https://adoptium.net/temurin/releases/?version=11

### Step 1: Install IntelliJ and Java

1. Download and install IntelliJ IDEA Community Edition
2. Download and install Java 11 JDK (Eclipse Temurin)
3. Open IntelliJ

### Step 2: Open the Project

1. In IntelliJ, click **File → Open**
2. Navigate to your plugin folder:
   - For JSONBin version: `/home/user/GBM`
   - For Discord version: `/home/user/GBMM`
3. Select the folder and click **OK**
4. IntelliJ will detect it's a Gradle project and import it

### Step 3: Configure JDK

1. Go to **File → Project Structure** (Ctrl+Alt+Shift+S)
2. Under **Project Settings → Project**:
   - Set **SDK** to Java 11
   - Set **Language Level** to 11
3. Click **Apply** and **OK**

### Step 4: Gradle Sync

1. IntelliJ should automatically sync Gradle
2. If not, click the **Gradle** tab on the right side
3. Click the **Reload** button (circular arrows icon)
4. Wait for dependencies to download (this may take a few minutes)

### Step 5: Create Run Configuration

#### Option A: Using the Test Class (Easiest)

1. Open the test file:
   - JSONBin version: `src/test/java/com/gbm/GroupBronzemanPluginTest.java`
   - Discord version: `src/test/java/com/example/ExamplePluginTest.java`

2. Right-click on the file in the editor
3. Click **Run 'GroupBronzemanPluginTest.main()'**
4. RuneLite will launch with your plugin loaded!

#### Option B: Manual Run Configuration

1. Click **Run → Edit Configurations**
2. Click **+** (Add New Configuration)
3. Select **Application**
4. Configure:
   - **Name**: `RuneLite with Plugin`
   - **Main class**:
     - JSONBin: `com.gbm.GroupBronzemanPluginTest`
     - Discord: `com.example.ExamplePluginTest`
   - **Use classpath of module**: Select your module
   - **JRE**: Java 11
5. Click **Apply** and **OK**
6. Click the **Run** button (green play icon)

### Step 6: Test in RuneLite

Once RuneLite launches:

1. **Login to OSRS** (use a test account if possible)
2. **Check Plugin is Loaded**:
   - Click the wrench icon (Configuration)
   - Search for "Group Bronzeman Mode"
   - You should see your plugin settings!

3. **Configure the Plugin**:
   - For JSONBin version:
     - Enter your API Key
     - Enter your Bin ID
   - For Discord version:
     - Enter Bot Token
     - Enter Webhook URL
     - Enter Channel ID

4. **Test Basic Functionality**:
   - Open your bank → Should unlock all items
   - Pick up a new item → Should unlock it
   - Check RuneLite logs in IntelliJ console for debug messages

### Step 7: Debugging

IntelliJ lets you debug your plugin:

1. Set breakpoints by clicking in the left margin of your code
2. Click **Debug** button (bug icon) instead of **Run**
3. When code hits breakpoint, you can:
   - Inspect variables
   - Step through code
   - Evaluate expressions

**Useful Breakpoints:**
- `checkAndUnlockItem()` - When items are checked
- `syncFromRemote()` - When syncing from JSONBin/Discord
- `onMenuOptionClicked()` - When clicking GE options

### Troubleshooting IntelliJ

**"Cannot resolve symbol" errors:**
- Make sure Gradle sync completed successfully
- Try: **File → Invalidate Caches → Invalidate and Restart**

**Dependencies not downloading:**
- Check your internet connection
- Try: **Gradle tab → Reload All Gradle Projects**

**Wrong Java version:**
- Check **File → Project Structure → Project → SDK** is Java 11
- Check **Settings → Build → Compiler → Java Compiler** is set to 11

**Plugin not appearing in RuneLite:**
- Check the console output for errors
- Make sure the test class is running correctly
- Verify `runelite-plugin.properties` has correct plugin class name

---

## Method 2: External Plugin (For End Users)

This is how players would install your plugin once it's ready.

### Step 1: Build the Plugin

```bash
cd /home/user/GBM  # or /home/user/GBMM
./gradlew build
```

This creates a JAR file in `build/libs/`

### Step 2: Install to RuneLite

#### Windows
```bash
copy build\libs\*.jar %USERPROFILE%\.runelite\plugins\
```

#### macOS/Linux
```bash
cp build/libs/*.jar ~/.runelite/plugins/
```

### Step 3: Restart RuneLite

1. Close RuneLite completely
2. Launch RuneLite normally
3. Your plugin should load automatically

### Step 4: Verify Installation

1. Click the wrench icon (Configuration)
2. Search for your plugin name
3. Configure and test

---

## Method 3: RuneLite Plugin Hub (For Public Release)

Once your plugin is ready for public use:

1. Fork the RuneLite plugin-hub repository
2. Add your plugin manifest
3. Submit a pull request
4. After approval, it appears in the Plugin Hub

**Not needed for testing - use IntelliJ method above!**

---

## Quick Testing Checklist

Once you have the plugin running:

### Test 1: Bank Unlock
- [ ] Open bank
- [ ] Check console logs - should see unlock messages
- [ ] Check JSONBin.io (or Discord) - data should appear

### Test 2: Item Pickup
- [ ] Pick up a new item you don't have
- [ ] Should see unlock notification in-game
- [ ] Check logs for unlock message
- [ ] Verify pushed to remote

### Test 3: GE Restriction
- [ ] Go to Grand Exchange
- [ ] Try to buy an item you haven't unlocked
- [ ] Should be blocked with message
- [ ] Try to buy an unlocked item
- [ ] Should work normally

### Test 4: Sync
- [ ] Have a friend (or second account) unlock an item
- [ ] Wait for sync interval (or restart plugin)
- [ ] Should receive the unlock
- [ ] Should see notification

### Test 5: Configuration
- [ ] Toggle notifications on/off
- [ ] Change sync interval
- [ ] Verify settings save between restarts

---

## Recommended Development Workflow

1. **Start with IntelliJ** - Best for development
2. **Use Debug Mode** - Set breakpoints and inspect
3. **Check Logs** - Console output is your friend
4. **Test with Alt Account** - Safer than your main
5. **Verify Remote Storage** - Check JSONBin.io or Discord
6. **Build JAR for Friends** - Once stable, share with group

---

## Common Issues

**RuneLite won't start:**
- Check Java version is 11
- Check console for errors
- Try cleaning: `./gradlew clean build`

**Plugin won't load:**
- Check `runelite-plugin.properties` syntax
- Verify plugin class name is correct
- Check for compile errors in IntelliJ

**Items not unlocking:**
- Check if config is set correctly
- Look for errors in console
- Verify API key/tokens are valid

**GE restriction not working:**
- May need to test with different items
- Check console logs for method calls
- Verify item ID is being detected correctly

---

## Pro Tips

1. **Use Test Account**: Don't test on your main account
2. **Check Logs Frequently**: Most issues show up in logs
3. **Start Simple**: Test basic unlock before testing sync
4. **Use Breakpoints**: Debug mode is incredibly helpful
5. **Test Edge Cases**: Noted items, stackable items, etc.

Good luck testing! 🚀
